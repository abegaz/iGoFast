# iGoFast
Project objective: To develop an efficient, secure, and usable traffic signal control system that can be accessible for large group of people including the color-blind. 
