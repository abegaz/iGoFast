package edu.ung.mccb.csci.csci3300.iGoFast.Controller;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.util.Timer;
import java.util.TimerTask;

public class tylers
{
    @FXML
    Circle northGreen, southGreen, eastGreen, westGreen, northRed, southRed, eastRed, westRed, northYellow, southYellow, eastYellow, westYellow;

    @FXML
    Rectangle northSensor, southSensor, eastSensor, westSensor, northCar, southCar, eastCar, westCar;

    Timeline northToSouth = new Timeline();
    Timeline southToNorth = new Timeline();
    Timeline eastToWest = new Timeline();
    Timeline westToEast = new Timeline();

    boolean active = false;
    @FXML
    public void startSimulation()
    {
        keepChecking();

        if(active == false)
        {
            northCar.setOpacity(1.0);
            southCar.setOpacity(1.0);
            eastCar.setOpacity(1.0);
            westCar.setOpacity(1.0);

            /*
            northToSouth.setCycleCount(Timeline.INDEFINITE);
            northToSouth.setAutoReverse(false);
            northToSouth.getKeyFrames().add(new KeyFrame(Duration.millis(10000),
                    new KeyValue(northCar.translateYProperty(), 540)));
            northToSouth.play();
            */

            southToNorth.setCycleCount(Timeline.INDEFINITE);
            southToNorth.setAutoReverse(false);
            southToNorth.getKeyFrames().add(new KeyFrame(Duration.millis(10000),
                    new KeyValue(southCar.translateYProperty(), -540)));
            southToNorth.play();

            westToEast.setCycleCount(Timeline.INDEFINITE);
            westToEast.setAutoReverse(false);
            westToEast.getKeyFrames().add(new KeyFrame(Duration.millis(15000),
                    new KeyValue(westCar.translateXProperty(), 864)));
            westToEast.play();

            eastToWest.setCycleCount(Timeline.INDEFINITE);
            eastToWest.setAutoReverse(false);
            eastToWest.getKeyFrames().add(new KeyFrame(Duration.millis(15000),
                    new KeyValue(eastCar.translateXProperty(), -864)));
            eastToWest.play();


            active = true;
        }
    }

    public void changeLight()
    {
        if(northGreen.getOpacity() == 1.0)
        {
            greenToYellow_NS();

            yellowTimer_NS();
        }
        else if (northRed.getOpacity() == 1.0)
        {

            greenToYellow_EW();

            yellowTimer_EW();
        }
    }

    public void greenToYellow_NS() {
        northGreen.setOpacity(0.0);
        southGreen.setOpacity(0.0);
        northYellow.setOpacity(1.0);
        southYellow.setOpacity(1.0);
    }

    public void greenToYellow_EW() {
        eastGreen.setOpacity(0.0);
        westGreen.setOpacity(0.0);
        eastYellow.setOpacity(1.0);
        westYellow.setOpacity(1.0);
    }

    public void yellowToRed_NS() {
        northYellow.setOpacity(0.0);
        southYellow.setOpacity(0.0);
        northRed.setOpacity(1.0);
        southRed.setOpacity(1.0);
    }

    public void yellowToRed_EW() {
        eastYellow.setOpacity(0.0);
        westYellow.setOpacity(0.0);
        eastRed.setOpacity(1.0);
        westRed.setOpacity(1.0);
    }

    public void redToGreen_NS() {
        northRed.setOpacity(0.0);
        southRed.setOpacity(0.0);
        northGreen.setOpacity(1.0);
        southGreen.setOpacity(1.0);
    }

    public void redToGreen_EW() {
        eastRed.setOpacity(0.0);
        westRed.setOpacity(0.0);
        eastGreen.setOpacity(1.0);
        westGreen.setOpacity(1.0);
    }

    public void yellowTimer_NS()
    {
        timer_NS();

    }

    public void yellowTimer_EW()
    {

        timer_EW();

    }

    // timer, timer_EW, and timer_NS control the yellow light duration
    Timer timer = new Timer();

    public void timer_EW()
    {
        TimerTask task = new TimerTask()
        {

            private final int delay = 3;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    start++;
                }
                else {
                    cancel();
                    yellowToRed_EW();
                    short_timer_NS();
                }
            }

        };

        timer.schedule(task, 0, 2500);
    }

    public void timer_NS()
    {
        TimerTask task = new TimerTask()
        {

            private final int delay = 3;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    start++;
                }
                else {
                    cancel();
                    yellowToRed_NS();
                    short_timer_EW();
                }
            }

        };

        timer.schedule(task, 0, 2500);
    }

    // one_timer, short_timer_EW, and short_timer_NS control the pause before the next set of lights turn green
    Timer one_timer = new Timer();

    public void short_timer_EW()
    {
        TimerTask task = new TimerTask()
        {

            private final int delay = 2;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    start++;
                }
                else {
                    cancel();
                    redToGreen_EW();
                }
            }

        };

        one_timer.schedule(task, 0, 2000);
    }

    public void short_timer_NS()
    {
        TimerTask task = new TimerTask()
        {

            private final int delay = 2;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    start++;
                }
                else {
                    cancel();
                    redToGreen_NS();
                }
            }

        };

        one_timer.schedule(task, 0, 2000);
    }

    Timer checker = new Timer();

    public void keepChecking()
    {
        TimerTask task = new TimerTask()
        {
            private final int delay = 0;
            private int start = 1;
            @Override
            public void run()
            {
                if(start > delay)
                {
                    //System.out.println(start);
                    start++;
                    carPresent();
                    carsGo();
                    manipulateTimer();
                }
                else {
                    cancel();
                }
            }
        };

        checker.schedule(task, 0, 1000);
    }


    // create a timer that calls this method every second checking for if a car is at a light
    boolean presentN = false, presentS = false, presentE = false, presentW = false;

    public void carPresent()
    {
        double yNS = northSensor.getLayoutY(), ySS = southSensor.getLayoutY(), xES = eastSensor.getLayoutX(), xWS = westSensor.getLayoutX();

        if((northCar.getTranslateY() > yNS && northCar.getTranslateY() < (yNS + northSensor.getHeight())) && (northRed.getOpacity() == 1.0 || northYellow.getOpacity() == 1.0))
        {
            northToSouth.pause();
            presentN = true;
            System.out.println("Car present at North light.");
        }
        if(((southCar.getLayoutY() + southCar.getTranslateY()) > ySS && (southCar.getLayoutY() + southCar.getTranslateY()) < (ySS + southSensor.getHeight())) && (southRed.getOpacity() == 1.0 || southYellow.getOpacity() == 1.0))
        {
            southToNorth.pause();
            presentS = true;
            System.out.println("Car present at South light.");
        }
        if(((eastCar.getLayoutX() + eastCar.getTranslateX()) > xES && (eastCar.getLayoutX() + eastCar.getTranslateX()) < (xES + eastSensor.getWidth())) && (eastRed.getOpacity() == 1.0 || eastYellow.getOpacity() == 1.0))
        {
            presentE = true;
            System.out.println("Car present at East light.");
            eastToWest.pause();
        }
        if((westCar.getTranslateX() > xWS && westCar.getTranslateX() < (xWS + westSensor.getWidth())) && (westRed.getOpacity() == 1.0 || westYellow.getOpacity() == 1.0))
        {
            presentW = true;
            System.out.println("Car present at West light.");
            westToEast.pause();
        }
    }

    public void carsGo()
    {
        if(presentN == true && northGreen.getOpacity() == 1.0)
        {
            northToSouth.play();

            presentN = false;
        }
        if (presentS == true && southGreen.getOpacity() == 1.0)
        {
            southToNorth.play();

            presentS = false;
        }
        if (presentE == true && eastGreen.getOpacity() == 1.0)
        {
            eastToWest.play();

            presentE = false;
        }
        if (presentW == true && westGreen.getOpacity() == 1.0)
        {
            westToEast.play();

            presentW = false;
        }
    }


    public boolean started = false;

    // Constantly called checking for a condition to be met
    public void manipulateTimer()
    {
        if(presentE == true && presentW == false && northGreen.getOpacity() == 1.0 && started == false && justChanged == false)
        {
            case1();
            started = true;
        }
        else if(presentE == true && presentW == true && northGreen.getOpacity() == 1.0 && started == false && justChanged == false)
        {
            case2();
            started = true;
        }
        if(presentE == false && presentW == true && northGreen.getOpacity() == 1.0 && started == false && justChanged == false)
        {
            case1();
            started = true;
        }
        else if(presentN == true && presentS == false && westGreen.getOpacity() == 1.0 && started == false && justChanged == false)
        {
            case1();
            started = true;
        }
        else if(presentN == true && presentS == true && westGreen.getOpacity() == 1.0 && started == false && justChanged == false)
        {
            case2();
            started = true;
        }
        else if(presentN == false && presentS == true && westGreen.getOpacity() == 1.0 && started == false && justChanged == false)
        {
            case1();
            started = true;
        }
    }


    Timer case1Timer = new Timer();

    //The case that one lane is waiting to go after unlock
    public void case1()
    {
        System.out.println("One lane waiting. Starting 20 Second Timer.");
        TimerTask task = new TimerTask()
        {
            private final int loopDelay = 20;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < loopDelay)
                {
                    System.out.println(start);
                    start++;
                }
                else {
                    cancel();
                    started = false;
                    changeLight();

                    justChanged = true;
                    lockLights();
                }
            }

        };

        case1Timer.schedule(task, 0, 1000);
    }

    Timer case2Timer = new Timer();

    //The case that both lanes are waiting to go after unlock
    public void case2()
    {
        System.out.println("Two lanes waiting. Starting 10 Second Timer.");

        TimerTask task = new TimerTask()
        {
            private final int loopDelay = 10;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < loopDelay)
                {
                    System.out.println(start);
                    start++;
                }
                else {
                    cancel();
                    started = false;
                    changeLight();

                    justChanged = true;
                    lockLights();
                }
            }

        };

        case2Timer.schedule(task, 0, 1000);
    }

    public boolean justChanged = false;

    Timer lockTimer = new Timer();

    // This timer locks the lights right after justChanged is set to true. It then releases the lock to allow the next timer to start
    public void lockLights()
    {
        System.out.println("Locking Lights 35 Seconds.");

        TimerTask task = new TimerTask()
        {
            private final int loopDelay = 20;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < loopDelay)
                {
                    System.out.println(start);
                    start++;
                }
                else {
                    cancel();
                    justChanged = false;
                }
            }

        };

        lockTimer.schedule(task, 0, 1000);
    }


}

