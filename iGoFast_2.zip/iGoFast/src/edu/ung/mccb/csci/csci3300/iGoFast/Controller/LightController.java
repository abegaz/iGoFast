package edu.ung.mccb.csci.csci3300.iGoFast.Controller;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.util.*;

public class LightController
{
    public LightController(){

    }
    @FXML
    Circle northGreen, southGreen, eastGreen, westGreen, northRed, southRed, eastRed, westRed, northYellow, southYellow, eastYellow, westYellow;

    @FXML
    Rectangle northSensor, southSensor, eastSensor, westSensor, northCar, southCar, eastCar, westCar;

    Timeline northToSouth = new Timeline();
    Timeline northToSouth2 = new Timeline();
    Timeline northToSouth3 = new Timeline();
    Timeline southToNorth = new Timeline();
    Timeline southToNorth2 = new Timeline();
    Timeline southToNorth3 = new Timeline();
    Timeline eastToWest = new Timeline();
    Timeline eastToWest2 = new Timeline();
    Timeline eastToWest3 = new Timeline();
    Timeline westToEast = new Timeline();
    Timeline westToEast2 = new Timeline();
    Timeline westToEast3 = new Timeline();

    Rectangle cars[] = new Rectangle[4];
    Rectangle currCarW;
    Rectangle currCarW2;
    Rectangle currCarW3;
    Rectangle currCarN;
    Rectangle currCarN2;
    Rectangle currCarN3;
    Rectangle currCarE;
    Rectangle currCarE2;
    Rectangle currCarE3;
    Rectangle currCarS;
    Rectangle currCarS2;
    Rectangle currCarS3;

    Queue<Rectangle> laneW = new LinkedList<>();
    Queue<Rectangle> laneN = new LinkedList<>();
    Queue<Rectangle> laneE = new LinkedList<>();
    Queue<Rectangle> laneS = new LinkedList<>();


    boolean laneNpresent = false;
    boolean laneSpresent = false;
    boolean laneEpresent = false;
    boolean laneWpresent = false;


    int Counter1 = 0;
    int Counter2 = 0;
    int Counter3 = 0;
    int Counter4 = 0;
    int Counter = 0;
    int stagDistance = 43;

    public void popArray(){
        cars[0] = northCar;
        cars[1] = southCar;
        cars[2] = eastCar;
        cars[3] = westCar;
        spawn();
    }

    public void spawn(){
        for(int i =0; i<cars.length; i++) {
            car_Arrive2();
        }

        GoLaneW();
        GoLaneN();
        GoLaneE();
        GoLaneS();
        ChangeLight();
    }

    Random rand = new Random();
    public int gen_num(){
        int  n = rand.nextInt(4) + 1;
        return n;
    }

    public void car_Arrive2(){
        int lane = gen_num();
        System.out.print(lane);
        switch(lane){
            case 1:
                Counter1++;
                carTOlaneW();
                break;
            case 2:
                Counter2++;
                carTOlaneN();
                break;
            case 3:
                Counter3++;
                carTOlaneE();
                break;
            case 4:
                Counter4++;
                carTOlaneS();
                break;
        }
    }
    public void carTOlaneW(){
        cars[Counter].relocate(0,295);
        laneW.add(cars[Counter]);
        laneWpresent = true;
        Counter++;
        //simulation();
    }
    public void carTOlaneN(){
        cars[Counter].relocate(362,0);
        laneN.add(cars[Counter]);
        laneNpresent = true;
        Counter++;
        //simulation();
    }
    public void carTOlaneE(){
        cars[Counter].relocate(864,219);
        laneE.add(cars[Counter]);
        laneEpresent = true;
        Counter++;
        //simulation();
    }
    public void carTOlaneS(){
        cars[Counter].relocate(451,559);
        laneS.add(cars[Counter]);
        laneSpresent = true;
        Counter++;
        //simulation();
    }
    public void GoLaneW(){
        for(int i=0; i<Counter1; i++) {
            if(laneW.peek()!=null) {
                currCarW = laneW.remove();
            }
            if(laneW.peek()!=null){
                currCarW2 = laneW.remove();
            }
            if(laneW.peek()!=null){
                currCarW3 = laneW.remove();
            }
            //simulation1();
        }
    }
    public void GoLaneN(){
        for(int i=0; i<Counter2; i++) {
            if(laneN.peek()!=null) {
                currCarN = laneN.remove();
            }
            if(laneN.peek()!=null){
                currCarN2 = laneN.remove();
            }
            if(laneN.peek()!=null){
                currCarN3 = laneN.remove();
            }
            //simulation2();
        }
    }
    public void GoLaneE(){
        for(int i=0; i<Counter3; i++) {
            if(laneE.peek()!=null) {
                currCarE = laneE.remove();
            }
            if(laneE.peek()!=null){
                currCarE2 = laneE.remove();
            }
            if(laneE.peek()!=null){
                currCarE3 = laneE.remove();
            }
            //simulation3();
        }
    }
    public void GoLaneS(){
        for(int i=0; i<Counter4; i++) {
            if(laneS.peek()!=null) {
                currCarS = laneS.remove();
            }
            if(laneS.peek()!=null){
                currCarS2 = laneS.remove();
            }
            if(laneS.peek()!=null){
                currCarS3 = laneS.remove();
            }
            //simulation4();
        }
    }




    boolean active = false;
    @FXML
    public void ChangeLight()
    {
        //popArray();
        if(active == false)
        {
            if(laneNpresent==true) {
                northToSouth.setCycleCount(Timeline.INDEFINITE);
                northToSouth.setAutoReverse(false);
                northToSouth.getKeyFrames().add(new KeyFrame(Duration.millis(10000),
                        //changed from northCar to currCarN
                        new KeyValue(currCarN.translateYProperty(), 540)));
                northToSouth.play();
                if(Counter2>1){
                    northToSouth2.setCycleCount(Timeline.INDEFINITE);
                    northToSouth2.setAutoReverse(false);
                    northToSouth2.getKeyFrames().add(new KeyFrame(Duration.millis(15000),
                            //changed from northCar to currCarN
                            new KeyValue(currCarN2.translateYProperty(), 540)));
                    northToSouth2.play();
                }
                if(Counter2==3){
                    northToSouth3.setCycleCount(Timeline.INDEFINITE);
                    northToSouth3.setAutoReverse(false);
                    northToSouth3.getKeyFrames().add(new KeyFrame(Duration.millis(20000),
                            //changed from northCar to currCarN
                            new KeyValue(currCarN3.translateYProperty(), 540)));
                    northToSouth3.play();
                }
            }

            if(laneSpresent==true) {
                southToNorth.setCycleCount(Timeline.INDEFINITE);
                southToNorth.setAutoReverse(false);
                southToNorth.getKeyFrames().add(new KeyFrame(Duration.millis(10000),
                        //changed from SouthCar
                        new KeyValue(currCarS.translateYProperty(), -540)));
                southToNorth.play();
                if(Counter4>1){
                    southToNorth2.setCycleCount(Timeline.INDEFINITE);
                    southToNorth2.setAutoReverse(false);
                    southToNorth2.getKeyFrames().add(new KeyFrame(Duration.millis(15000),
                            //changed from SouthCar
                            new KeyValue(currCarS2.translateYProperty(), -540)));
                    southToNorth2.play();
                }
                if(Counter4==3){
                    southToNorth3.setCycleCount(Timeline.INDEFINITE);
                    southToNorth3.setAutoReverse(false);
                    southToNorth3.getKeyFrames().add(new KeyFrame(Duration.millis(20000),
                            //changed from SouthCar
                            new KeyValue(currCarS3.translateYProperty(), -540)));
                    southToNorth3.play();
                }
            }

            if(laneWpresent==true) {
                westToEast.setCycleCount(Timeline.INDEFINITE);
                westToEast.setAutoReverse(false);
                westToEast.getKeyFrames().add(new KeyFrame(Duration.millis(15000),
                        new KeyValue(currCarW.translateXProperty(), 864)));
                westToEast.play();
                if(Counter1>1){
                    westToEast2.setCycleCount(Timeline.INDEFINITE);
                    westToEast2.setAutoReverse(false);
                    westToEast2.getKeyFrames().add(new KeyFrame(Duration.millis(20000),
                            new KeyValue(currCarW2.translateXProperty(), 864)));
                    westToEast2.play();
                }
                if(Counter1==3){
                    westToEast3.setCycleCount(Timeline.INDEFINITE);
                    westToEast3.setAutoReverse(false);
                    westToEast3.getKeyFrames().add(new KeyFrame(Duration.millis(25000),
                            new KeyValue(currCarW3.translateXProperty(), 864)));
                    westToEast3.play();
                }
            }

            if(laneEpresent==true) {
                eastToWest.setCycleCount(Timeline.INDEFINITE);
                eastToWest.setAutoReverse(false);
                eastToWest.getKeyFrames().add(new KeyFrame(Duration.millis(15000),
                        new KeyValue(currCarE.translateXProperty(), -864)));
                eastToWest.play();
                if(Counter3>1){
                    eastToWest2.setCycleCount(Timeline.INDEFINITE);
                    eastToWest2.setAutoReverse(false);
                    eastToWest2.getKeyFrames().add(new KeyFrame(Duration.millis(20000),
                            new KeyValue(currCarE2.translateXProperty(), -864)));
                    eastToWest2.play();
                }
                if(Counter3==3){
                    eastToWest3.setCycleCount(Timeline.INDEFINITE);
                    eastToWest3.setAutoReverse(false);
                    eastToWest3.getKeyFrames().add(new KeyFrame(Duration.millis(25000),
                            new KeyValue(currCarE3.translateXProperty(), -864)));
                    eastToWest3.play();
                }
            }

            active = true;
        }


        if(northGreen.getOpacity() == 1.0){
            greenToYellow_NS();

            yellowTimer_NS();
        }
        else if (northRed.getOpacity() == 1.0){

            greenToYellow_EW();

            yellowTimer_EW();
        }


        loop_method();
    }

    public void greenToYellow_NS() {
        northGreen.setOpacity(0.0);
        southGreen.setOpacity(0.0);
        northYellow.setOpacity(1.0);
        southYellow.setOpacity(1.0);
    }

    public void greenToYellow_EW() {
        eastGreen.setOpacity(0.0);
        westGreen.setOpacity(0.0);
        eastYellow.setOpacity(1.0);
        westYellow.setOpacity(1.0);
    }

    public void yellowToRed_NS() {
        northYellow.setOpacity(0.0);
        southYellow.setOpacity(0.0);
        northRed.setOpacity(1.0);
        southRed.setOpacity(1.0);
    }

    public void yellowToRed_EW() {
        eastYellow.setOpacity(0.0);
        westYellow.setOpacity(0.0);
        eastRed.setOpacity(1.0);
        westRed.setOpacity(1.0);
    }

    public void redToGreen_NS() {
        northRed.setOpacity(0.0);
        southRed.setOpacity(0.0);
        northGreen.setOpacity(1.0);
        southGreen.setOpacity(1.0);
    }

    public void redToGreen_EW() {
        eastRed.setOpacity(0.0);
        westRed.setOpacity(0.0);
        eastGreen.setOpacity(1.0);
        westGreen.setOpacity(1.0);
    }

    public void yellowTimer_NS()
    {
        timer_NS();

    }

    public void yellowTimer_EW()
    {

        timer_EW();

    }

    // timer, timer_EW, and timer_NS control the yellow light duration
    Timer timer = new Timer();

    public void timer_EW()
    {
        TimerTask task = new TimerTask()
        {

            private final int delay = 3;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    start++;
                }
                else {
                    cancel();
                    yellowToRed_EW();
                    short_timer_NS();
                }
            }

        };

        timer.schedule(task, 0, 2500);
    }

    public void timer_NS()
    {
        TimerTask task = new TimerTask()
        {

            private final int delay = 3;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    start++;
                }
                else {
                    cancel();
                    yellowToRed_NS();
                    short_timer_EW();
                }
            }

        };

        timer.schedule(task, 0, 2500);
    }

    // one_timer, short_timer_EW, and short_timer_NS control the pause before the next set of lights turn green
    Timer one_timer = new Timer();

    public void short_timer_EW()
    {
        TimerTask task = new TimerTask()
        {

            private final int delay = 2;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    start++;
                }
                else {
                    cancel();
                    redToGreen_EW();
                }
            }

        };

        one_timer.schedule(task, 0, 2000);
    }

    public void short_timer_NS()
    {
        TimerTask task = new TimerTask()
        {

            private final int delay = 2;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    start++;
                }
                else {
                    cancel();
                    redToGreen_NS();
                }
            }

        };

        one_timer.schedule(task, 0, 2000);
    }


    // LoopTimer and loop_method are the master timers for the entire system. They set the time until the next light change
    // This timer must be manipulated based on traffic patterns
    Timer loopTimer = new Timer();

    public void loop_method()
    {
        TimerTask task = new TimerTask()
        {
            private final int delay = 30;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    //System.out.println(start);
                    start++;
                    carPresent();
                    carsGo();
                }
                else {
                    cancel();
                    ChangeLight();
                }
            }

        };

        loopTimer.schedule(task, 0, 1000);
    }


    // create a timer that calls this method every second checking for if a car is at a light
    boolean presentN = false, presentS = false, presentE = false, presentW = false;

    public void carPresent() {
        double yNS = northSensor.getLayoutY(), ySS = southSensor.getLayoutY(), xES = eastSensor.getLayoutX(), xWS = westSensor.getLayoutX();
        //changed eastCar to currCarE
        //System.out.println(currCarE.getLayoutX() + currCarE.getTranslateX());
        System.out.println(eastSensor.getLayoutX() + eastSensor.getWidth());
        System.out.println(xES);
        //changed northCar to currCarN
        //added this if statement so if lane doesn't have car it doesnt run
        if (laneNpresent == true) {
            if ((currCarN.getTranslateY() > yNS && currCarN.getTranslateY() < (yNS + northSensor.getHeight())) && (northRed.getOpacity() == 1.0 || northYellow.getOpacity() == 1.0)) {
                northToSouth.pause();
                //northToSouth2.pause();
                //northToSouth3.pause();
                presentN = true;
                System.out.println("Car present at North light.");
            }
            if (Counter2 > 1) {
                if ((currCarN2.getTranslateY() > yNS && currCarN2.getTranslateY() < (yNS + northSensor.getHeight())) && (northRed.getOpacity() == 1.0 || northYellow.getOpacity() == 1.0)) {
                    northToSouth2.pause();
                    presentN = true;
                    System.out.println("Car present at North light.");
                }
            }
            if (Counter2 == 3) {
                if ((currCarN3.getTranslateY() > yNS && currCarN3.getTranslateY() < (yNS + northSensor.getHeight())) && (northRed.getOpacity() == 1.0 || northYellow.getOpacity() == 1.0)) {
                    northToSouth3.pause();
                    presentN = true;
                    System.out.println("Car present at North light.");
                }
            }
        }
        //changed southCar to currCarS
        if (laneSpresent == true) {
            if (((currCarS.getLayoutY() + currCarS.getTranslateY()) > ySS && (currCarS.getLayoutY() + currCarS.getTranslateY()) < (ySS + southSensor.getHeight())) && (southRed.getOpacity() == 1.0 || southYellow.getOpacity() == 1.0)) {
                southToNorth.pause();
                //southToNorth2.pause();
                //southToNorth3.pause();
                presentS = true;
                System.out.println("Car present at South light.");
            }
            if (Counter4 > 1) {
                if (((currCarS2.getLayoutY() + currCarS2.getTranslateY()) > ySS && (currCarS2.getLayoutY() + currCarS2.getTranslateY()) < (ySS + southSensor.getHeight())) && (southRed.getOpacity() == 1.0 || southYellow.getOpacity() == 1.0)) {
                    southToNorth2.pause();
                    presentS = true;
                    System.out.println("Car present at South light.");
                }
            }
            if (Counter4 == 3) {
                if (((currCarS3.getLayoutY() + currCarS3.getTranslateY()) > ySS && (currCarS3.getLayoutY() + currCarS3.getTranslateY()) < (ySS + southSensor.getHeight())) && (southRed.getOpacity() == 1.0 || southYellow.getOpacity() == 1.0)) {
                    southToNorth3.pause();
                    presentS = true;
                    System.out.println("Car present at South light.");
                }
            }
        }
        //eastCar to currCarE
        if (laneEpresent == true) {
            if (((currCarE.getLayoutX() + currCarE.getTranslateX()) > xES && (currCarE.getLayoutX() + currCarE.getTranslateX()) < (xES + eastSensor.getWidth())) && (eastRed.getOpacity() == 1.0 || eastYellow.getOpacity() == 1.0)) {
                presentE = true;
                System.out.println("Car present at East light.");
                eastToWest.pause();
//                eastToWest2.pause();
//                eastToWest3.pause();
            }
            if (Counter3 > 1) {
                if (((currCarE2.getLayoutX() + currCarE2.getTranslateX()) > xES && (currCarE2.getLayoutX() + currCarE2.getTranslateX()) < (xES + eastSensor.getWidth())) && (eastRed.getOpacity() == 1.0 || eastYellow.getOpacity() == 1.0)) {
                    presentE = true;
                    System.out.println("Car present at East light.");
                    eastToWest2.pause();
                }
            }
            if (Counter3 == 3) {
                if (((currCarE3.getLayoutX() + currCarE3.getTranslateX()) > xES && (currCarE3.getLayoutX() + currCarE3.getTranslateX()) < (xES + eastSensor.getWidth())) && (eastRed.getOpacity() == 1.0 || eastYellow.getOpacity() == 1.0)) {
                    presentE = true;
                    System.out.println("Car present at East light.");
                    eastToWest3.pause();
                }
            }
        }
        //westCar to currCarW
        if (laneWpresent == true) {
            if ((currCarW.getTranslateX() > xWS && currCarW.getTranslateX() < (xWS + westSensor.getWidth())) && (westRed.getOpacity() == 1.0 || westYellow.getOpacity() == 1.0)) {
                presentW = true;
                System.out.println("Car present at West light.");
                westToEast.pause();
//                westToEast2.pause();
//                westToEast3.pause();
            }
            if (Counter1 > 1) {
                if ((currCarW2.getTranslateX() > xWS && currCarW2.getTranslateX() < (xWS + westSensor.getWidth())) && (westRed.getOpacity() == 1.0 || westYellow.getOpacity() == 1.0)) {
                    presentW = true;
                    System.out.println("Car present at West light.");
                    westToEast2.pause();
                }
            }
            if (Counter == 3) {
                if ((currCarW3.getTranslateX() > xWS && currCarW3.getTranslateX() < (xWS + westSensor.getWidth())) && (westRed.getOpacity() == 1.0 || westYellow.getOpacity() == 1.0)) {
                        presentW = true;
                        System.out.println("Car present at West light.");
                        westToEast3.pause();
                }
            }
        }
    }

    public void carsGo()
    {
        if(presentN == true && northGreen.getOpacity() == 1.0)
        {
            northToSouth.play();
            northToSouth2.play();
            northToSouth3.play();

            presentN = false;
        }
        if (presentS == true && southGreen.getOpacity() == 1.0)
        {
            southToNorth.play();
            southToNorth2.play();
            southToNorth3.play();

            presentS = false;
        }
        if (presentE == true && eastGreen.getOpacity() == 1.0)
        {
            eastToWest.play();
            eastToWest2.play();
            eastToWest3.play();

            presentE = false;
        }
        if (presentW == true && westGreen.getOpacity() == 1.0)
        {
            westToEast.play();
            westToEast2.play();
            westToEast3.play();

            presentW = false;
        }
    }

    Timer carTracker = new Timer();

    public void trackCars_timer()
        {
        TimerTask task = new TimerTask()
        {
            private final int delay = 1;
            private int start = 0;
            @Override
            public void run()
            {
                if(start < delay)
                {
                    System.out.println(start);
                    start++;
                }
                else {
                    cancel();
                    carPresent();
                }
            }

        };

        carTracker.schedule(task, 0, 1000);
    }





}
